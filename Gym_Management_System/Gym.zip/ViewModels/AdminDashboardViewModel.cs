public class AdminDashboardViewModel
{
  public required int TotalMembers { get; set; }
  public required int TotalTrainers { get; set; }
  public required int TotalSessions { get; set; }
  public required int TotalBranches { get; set; }
}
