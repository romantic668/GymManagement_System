namespace GymManagement.ViewModels.Payments
{
    public class ChartBarViewModel
    {
        public string Month { get; set; } = string.Empty;
        public decimal Total { get; set; }
    }
}
