using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema; // 🔹 加上这一行
using Microsoft.AspNetCore.Identity;

namespace GymManagement.Models
{
  public class User : IdentityUser
  {
    [Required]
    public string Name { get; set; } = "";

    public DateTime JoinDate { get; set; } = DateTime.UtcNow;

    [NotMapped] // 🔹 防止 EF 把 RoleNames 映射到数据库
    public IList<string>? RoleNames { get; set; }
  }
}
