using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GymManagement.Models
{
  public class EditProfileViewModel
  {
    public string? UserName { get; set; }

    [Required(ErrorMessage = "Full name is required.")]
    [Display(Name = "Full Name")]
    public string Name { get; set; } = "";

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Invalid email format.")]
    [Remote(action: "CheckEmailEdit", controller: "Validation", ErrorMessage = "This email is already registered.")]
    public string Email { get; set; } = "";

    [DataType(DataType.Date)]
    [Display(Name = "Date of Birth")]
    public DateTime? DOB { get; set; }

    public string? ProfileImageUrl { get; set; }

    public IList<string> RoleNames { get; set; } = new List<string>();

    public IFormFile? ProfileImageFile { get; set; }

    [Display(Name = "New Password")]
    [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters.")]
    [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$",
        ErrorMessage = "Password must include upper, lower, number, and special character.")]
    public string? Password { get; set; }

    [Display(Name = "Confirm Password")]
    [Compare("Password", ErrorMessage = "Passwords do not match.")]
    public string? ConfirmPassword { get; set; }
  }
}
