public class SessionViewModel
{
  public required string ClassName { get; set; }
  public required DateTime SessionDate { get; set; }
  public required string RoomName { get; set; }
  public required int TotalBookings { get; set; }
}
